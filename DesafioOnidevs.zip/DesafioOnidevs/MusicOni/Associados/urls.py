from django.urls import path, include

from . import views

urlpatterns = [
    path('', views.Associados_form, name='Associados_insert'),

    path('<int:id>/', views.Associados_form, name='Associados_update'),

    path('delete/<int:id>/', views.Associados_delete, name='Associados_delete'),

    path('list/', views.Associados_list, name='Associados_list')
]
