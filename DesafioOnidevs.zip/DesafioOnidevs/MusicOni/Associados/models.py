from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Artist(models.Model):
    name = models.CharField(max_length=30)
    date_joined = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
   # Deixa o post lá no admin com o nome escolhido


class Song(models.Model):
    title = models.CharField(max_length=50)
    spotify_published = models.BooleanField(default=False)
    youtube_published = models.BooleanField(default=False)
    duration = models.TimeField(null=True)
    artist = models.ForeignKey(Artist, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
   # Deixa o post lá no admin com o nome escolhido
