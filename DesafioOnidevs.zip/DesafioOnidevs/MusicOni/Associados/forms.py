from django import forms
from .models import Song


class AssociadosForm(forms.ModelForm):

    class Meta:
        model = Song
        fields = ('title', 'spotify_published',
                  'youtube_published', 'duration', 'artist')
        labels = {
            'title': 'Título da música',
            'spotify_published': 'Marque se sua música já foi publicada no Spotify',
            'youtube_published': 'Marque se sua música já foi publicada no Youtube',
            'duration': 'Duração da música',
            'artist': 'Artista MusicOni',
        }

    def __init__(self, *args, **kwargs):
        super(AssociadosForm, self).__init__(*args, **kwargs)
        self.fields['artist'].empty_label = "Selecione"
