from django.apps import AppConfig


class AssociadosConfig(AppConfig):
    name = 'Associados'
