from django.shortcuts import render, redirect

from .forms import AssociadosForm

from .models import Song

# Create your views here.


def Associados_list(request):

    context = {'Associados_list': Song.objects.all()}
    return render(request, "Associados/Associados_list.html", context)
# Este codigo serve para que todos os objetos do model Song vá para o Associados/list


def Associados_form(request, id=0):

    if request.method == "GET":
        if id == 0:
            form = AssociadosForm()

        else:
            Associados = Song.objects.get(pk=id)
            form = AssociadosForm(instance=Associados)
        return render(request, "Associados/Associados_form.html", {'form': form})

    else:
        if id == 0:
            form = AssociadosForm(request.POST)

        else:
            Associados = Song.objects.get(pk=id)
            form = AssociadosForm(request.POST, instance=Associados)

        if form.is_valid():
            form.save()
        return redirect('/Associados/list')


def Associados_delete(request, id):
    Associados = Song.objects.get(pk=id)
    Associados.delete()
    return redirect('/Associados/list')
# Com isso é possivel excluir as músicas criadas
